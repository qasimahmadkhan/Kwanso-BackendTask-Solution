module.exports = {
    'secret':'nodeauthsecret',
    'database': 'mongodb+srv://qasim:qasim123@nodeapplication.me7nd.mongodb.net/Task'
  };
  